const express = require('express');
const logoutRouter = express.Router();
const session = require('express-session');
const passport = require('passport');
const profiles = require('../../src/models/profile.js');
const mongoose = require('mongoose');

logoutRouter.use(express.json());

logoutRouter.get('/', async (req, res) =>{

    console.log(req.sessionID);
    
    try{
        res.render("logout", {
            title: "Logout"
        });
    }    
    catch(err){
        console.error(err);
        res.render("logout", {
            title: "Logout"
        });
    }
});

logoutRouter.post('/', async (req, res) =>{ //test logout

    console.log("mogus");
    
    req.logout(function(err) {
        if (err) { return next(err); }
        res.redirect('/');
    });
});

module.exports = logoutRouter;