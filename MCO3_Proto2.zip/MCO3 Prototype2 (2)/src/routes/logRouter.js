const express = require('express');
const logRouter = express.Router();
const session = require('express-session');
const cookieParser = require('cookie-parser');
const profiles = require('../../src/models/profile.js');
const mongoose = require('mongoose');
const initializePassport = require('./passport-config.js');
const passport = require('passport');
const flash = require('express-flash');

logRouter.use(session({
    secret: 'lmao guess',
    resave: false,
    saveUninitialized: false,
}));
logRouter.use(flash());
logRouter.use(express.json());
logRouter.use(passport.initialize());
logRouter.use(passport.session());
logRouter.use(cookieParser());

logRouter.use((req,res,next) =>{
    req.time = new Date(Date.now()).toString();
    console.log(req.method,req.hostname, req.path, req.time);
    next();
});

logRouter.use(function(err, req, res, next) {
    console.log(err);
});

initializePassport(
    passport, 
    async email => await profiles.find( {email: email} ),
    async id => await profiles.find( {id: id} )
);

logRouter.get('/', async (req, res) =>{
    try{
        res.render("login", {
            title: "Login"
        });
    }    
    catch(err){
        console.error(err);
        res.render("login", {
            title: "Login"
        });
    }
});

logRouter.post('/', passport.authenticate('local', { //test remember me
    successRedirect: '/', //profile page  link goes here
    failureRedirect: '/login',
    failureFlash: true
}), function(req, res) {
    console.log(req.body.remember);
    if (req.body.remember) {
        console.log("if for cookie not working");
        res.cookie('myCookie', 'cookieValue', { maxAge: 10000, httpOnly: true });

        console.log("cookie:" + req.cookies);
    } else {
      req.session.cookie.expires = false; // Cookie expires at end of session
    }
  res.redirect('/');
})

module.exports = logRouter;