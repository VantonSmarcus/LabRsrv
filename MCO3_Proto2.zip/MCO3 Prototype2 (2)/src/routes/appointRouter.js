/**
 * To Do:
 * 1.) Need to make a function that gets the requested room and date from the search website DONE
 * 2.) Need to make a get function on the array of appointments DONE
 */

const { Router } = require('express')
const appointRouter = Router()

const Appointment = require('../models/Appointment.js')

var foundroom, founddate, founduser

appointRouter.post('/post-search-data', async(req,res) =>{
//  Function to get the fields for the search request (Room number, Date, and username)
    try{    
        foundroom = req.body[0]
        founddate = req.body[1]
        founduser = "Giancarloflores"

        console.log("Data received successfully")
        
    }catch(err) {
        console.log("Error: Unable to find Form field data")
    }
})  

appointRouter.get('/fetch-data', async(req,res) =>{
//  Retrieves the appointment data 
    const searchReq = {
        room: foundroom,
        date: founddate,
        user: founduser
    }

    const appoint = await Appointment.find({}).lean().exec()

    //const appoints = []
    res.send({searchReq, appoint})
})

//USE TO GET APPOINTMENTS DATA
appointRouter.get('/fetch-appoint-data', async(req,res) =>{
    const appoint = await Appointment.find({}).lean().exec()
    res.send({searchReq, appoint})
})

// appointRouter.get('/appoint/fetch-appoint-data', async(req,res)=>{
//     const appoint = await Appointment.find({}).lean().exec()
//     res.send(appoint)
// })

appointRouter.post('/create-appointment', async(req,res)=>{
//  Creates the appointment from the user
    try{
        const create = await Appointment.create({
            roomNum: req.body.roomNum,
            date: req.body.date,
            seatNum: req.body.seatNum,
            timeStart: req.body.timeStart,
            timeEnd: req.body.timeEnd,
            name: req.body.name,
            anon: req.body.anon
        })

        console.log(create)
        res.sendStatus(200)
    }catch(err){
        console.log("ERROR: Server side failed to create appointment")
        res.sendStatus(500)
    }
})

// function createsampledata(){
//     const result = Appointment.create({
//         roomNum: "321",
//         date: "March 13",
//         seatNum: 5,
//         timeStart: "9:00",
//         timeEnd: "10:00",
//         name: "GiancarloFlores",
//         anon: false
//     })
// }

module.exports = appointRouter