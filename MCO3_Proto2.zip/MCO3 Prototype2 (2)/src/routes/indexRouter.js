const express = require('express');
const reglogTest = express.Router();
const logRouter = require('./logRouter');
const regRouter = require('./regRouter');
const logoutRouter = require('./logoutRouter');
const searchRouter = require('./searchRouter.js');
const appointRouter = require('./appointRouter.js');
const profileRouter = require('./profileRouter.js');

//  ISAAC
reglogTest.use((req,res,next) =>{
    req.time = new Date(Date.now()).toString();
    console.log(req.method,req.hostname, req.path, req.time);
    next();
});

reglogTest.use(function(err, req, res, next) {
    console.log(err);
});

reglogTest.get('/', (req, res) => {
    console.log("home");
    res.render("homePage");
});

reglogTest.get('/lab', (req, res) => {
    console.log("lab");
    res.send("labpage");
});

//  GIAN
reglogTest.get('/labsearch', async function(req,res) {
    res.render('searchpage')
})

reglogTest.get('/labpage', async function(req,res) {
    try{
        const foundroom = req.query.room
        const founddate = req.query.date

        res.render('labpage', {
            roomNumber: foundroom,
            dateString: founddate,
            userName: "Giancarlo",
        })
        console.log("Success: Redirection is complete")
    }catch(err){
        console.log("Error: Unable to redirect to the website")
    }
})

// Rendering profileSearch.html
reglogTest.get('/profileSearch', (req, res) => {
    console.log("rendering profile Search");
    res.render('profileSearch');
});


reglogTest.use('/login', logRouter);
reglogTest.use('/signup', regRouter);
reglogTest.use('/logout', logoutRouter);
reglogTest.use('/labsearch', searchRouter);
reglogTest.use('/labpage', appointRouter);

module.exports = reglogTest;