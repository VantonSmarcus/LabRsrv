/**
 * To Do: 
 * 1.) Need to implement a get function and create dynamic dates for user options on date
 * 2.) Display the available options to the user screen
 */

const { Router } = require('express')

const searchRouter = Router()

searchRouter.get("/dates", async (req,res) =>{
    //  Get fuction for the DYNAMIC dates
    
})


module.exports = searchRouter