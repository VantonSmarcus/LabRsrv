/*class User{
    constructor(email, password){
        this.pfp;//editable/useable for profile pages
        this.desc;//editable/useable for profile pages
        this.email = email;//this might have to be the user name (also used in sorting and searching)
        this.password = password;//password

        if(email.endsWith("@dlsu.edu.ph")){ //statuses "S" for student "F" for facilitator, they are automatically deterined
            if(email.includes("_"))
                this.type = "S";
            if(!email.includes("_"))
                this.type = "F";
        }
        else
            this.status = "NA";
    }
    //below are getters and setters, u can use these ig if u can
    getEmail(){
        return this.email;
    }
    getPass(){
        return this.password;
    }
    getStatus(){
        return this.status;
    }
    getPfp(){
        return this.pfp;
    }
    getDesc(){
        return this.desc;
    }

    setEmail(email){
        this.email = email;
    }
    setPass(password){
        this.password = password;
    }
    setPfp(pfp){
        this.pfp = pfp;
    }
    setDesc(desc){
        this.desc = desc
    }
}

//this array for now holds 5 trial users but will be used as the memory to hold the database data
var listOfUser = new Array();
    listOfUser[0] = new User("harri_son@dlsu.edu.ph", "harrisonford");
    listOfUser[1] = new User("john_carbo@dlsu.edu.ph", "destructor");
    listOfUser[2] = new User("juice_wan@dlsu.edu.ph", "beep boop");
    listOfUser[3] = new User("karon.amog@dlsu.edu.ph", "12345");
    listOfUser[4] = new User("zela.clawlan@dlsu.edu.ph", "123456");

//when login button pressed

function loginSubmit(){
    let email = document.querySelector("input#mail").value; 
    let password = document.querySelector("input#pass").value;
    let rememberMe = document.querySelector("input#rememberMe").value;

    person = new User(email, password);

    //verify according to database/info storage
    userInDatabase = loginVerification(person);

    if(userInDatabase > -1 && person.status != "NA"){
        document.querySelector("p#errorMsg").textContent = "";

        if(person.password.localeCompare(listOfUser[userInDatabase].password) == 0){
            //window.location.href = "../profilePage/profile.html";
            console.log("logged in");
            let rememberYes = document.querySelector("input#rememberMe").checked;
            if(rememberYes){
            }
        }
        else{
            document.querySelector("p#errorMsg").textContent = "Error: Incorrect password";
            document.querySelector("input#pass").value = "";
        }
    }
    else if(userInDatabase == -1){
            document.querySelector("p#errorMsg").textContent = "Error: User does not exist";
            document.querySelector("input#pass").value = "";
    }
}

function loginVerification(user){

    return binarySearch(listOfUser, user);
}

//Start of function binarySearch() from https://www.geeksforgeeks.org/binary-search-a-string/
//author is user: rag2127
function binarySearch(userList, user){
    let first = 0;
    let last = userList.length - 1;
    let mid;

    while(first <= last){
        mid = first + Math.floor((last-first)/2);

        match_0 = user.email.localeCompare(userList[mid].email); //comparing email address

        if(match_0 == 0){
            return mid;
        }

        if(match_0 > 0){
            first = mid + 1;
        }

        else
            last = mid - 1;
    }

    return -1;
}
//End of binary search

function rememberCookie(mail){
    let week3 = new Date();
    let cookieString = ""

    week3.setTime(week3.getTime() + (21*24*60*60*1000));
    expireDate = week3.toUTCString();

    cookie = "email=" + mail + "; expires=" + expireDate + "; path=/";

    document.cookie = cookieString;
}

//when register button is pressed
function regSubmit(){
    let email = document.querySelector("input#mail").value; 
    let password = document.querySelector("input#pass").value;
    let passwordConf = document.querySelector("input#passConf").value;

    document.querySelector("p#errorMsg").textContent = "";
    userInDatabase = loginVerification(person);

    if(userInDatabase > -1){
        document.querySelector("p#errorMsg").textContent = "Error: User already exists";
        document.querySelector("input#pass").value = "";
        document.querySelector("input#passConf").value = "";
    }
    else if(!email.endsWith("@dlsu.edu.ph")){ //ask about this, users outside of dlsu might be allowed in? IDK
        document.querySelector("p#errorMsg").textContent = "Error: Incorrect email format";
        document.querySelector("input#pass").value = "";
        document.querySelector("input#passConf").value = "";
    }
    else if(!(password.localeCompare(passwordConf) == 0)){
        document.querySelector("p#errorMsg").textContent = "Error: Password confirmation incorrect";
        document.querySelector("input#pass").value = "";
        document.querySelector("input#passConf").value = "";
    }
    else{
        person = new User(email, password);
        listOfUser.push(person);
        quickSort(listOfUser, 0, listOfUser.length - 1);
        document.querySelector("input#mail").value = "";
        document.querySelector("input#pass").value = "";
        document.querySelector("input#passConf").value = "";
    }

    for(let i = 0; i < listOfUser.length; i++){ // for testing to view all users in memory rn check console in browser, remove if ur confident
        console.log(listOfUser[i].email);
    }
}

//Start of quick sort implementation from https://www.geeksforgeeks.org/javascript-program-for-quick-sort/
//author is not listed
function quickSort(list, first, last){

    if(first >= last)
        return;

    let pivot = partition(list, first, last);

    quickSort(list, first, pivot - 1);
    quickSort(list, pivot + 1, last);
}

function partition(list, first, last){

    let pivot = list[last].email;
    let i = first - 1;

    for(let j = first; j <= last - 1; j++){
        if(list[j].email.localeCompare(pivot) == -1){
            i++;
            let temp = list[j];
            list[j] = list[i];
            list[i] = temp;
        }
    }

    let temp = list[i + 1];
    list[i + 1] = list[last];
    list[last] = temp;
    return i + 1;
}
//Quicksort end*/

//OLD CODE ^
//         |

window.addEventListener("DOMContentLoaded", (event) => {
    document.getElementById("errorMsg").innerText = "";
    const submitBtn = document.getElementById("submit");

    if (submitBtn) {
        submitBtn.addEventListener("click", async (e) =>{
            e.preventDefault();
            let mail = document.getElementById("mail").value;
            let pass = document.getElementById("pass").value;
            
            if(mail == "" || pass == "")
                document.getElementById("errorMsg").innerText = "Error: Please fill out all text fields";
            //validate email and password
            else{
                try {
                    console.log('verifying user...');
                    var loginUser = {
                        "username": mail,
                        "email": mail,
                        "password": pass
                    };
    
                    let profileJstring = JSON.stringify(loginUser);
    
                    const response = await fetch('/login', {
                        method: 'POST',
                        body: profileJstring,
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    });

                    console.log(window.location.href);
                    let newURL = window.location.href.replace("/signup", "/login");
                    window.location.replace(newURL);
            
                    console.log(response);                    
                } catch (err) {
                    console.error(err);
                }
            }
        });
    }
    else
        console.log("loljk");
});