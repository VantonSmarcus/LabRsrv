window.addEventListener("DOMContentLoaded", (event) => {
    document.getElementById("errorMsg").innerText = "";
    const submitBtn = document.getElementById("submit");
    
    if (submitBtn) {
        submitBtn.addEventListener("click", async (e) =>{
            e.preventDefault();
            let mail = document.getElementById("mail").value;
            let pass = document.getElementById("pass").value;
            let conf = document.getElementById("passConf").value;

            document.getElementById("mail").value = '';
            document.getElementById("pass").value = '';
            document.getElementById("passConf").value = '';

            if(mail == "" || pass == "" || conf == "")
                document.getElementById("errorMsg").innerText = "Error: Please fill out all text fields";
            else if(pass.localeCompare(conf) != 0)
                document.getElementById("errorMsg").innerText = "Error: Password and confirm password do not match";
            else{
                try {
                    console.log('adding user...');
                    var signupUser = {
                        "username": mail,
                        "desc": 'default',
                        "pfp_link": '',
                        "user_type": 'S',
                        "email": mail,
                        "password": pass,
                        "remember": 0,
                        "session": ''
                    };

                    let profileJstring = JSON.stringify(signupUser);

                    const response = await fetch('/signup', {
                        method: 'POST',
                        body: profileJstring,
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    });

                    console.log("ITS WORKING ONG");
                    console.log(window.location);
                    
                    window.location.href="/login";

                    // let newURL = window.location.href;
                    // newURL.replace("/signup","/login");
                    // window.location.href = newURL;

                    console.log(response);
                } catch (err) {
                    console.error(err);
                }
            }
        });
    }
    else
        console.log("lol pain");
});